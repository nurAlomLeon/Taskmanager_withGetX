class AssetsPath {

  static const String _imagePath="assets/images";
  static const String backgroundImage="$_imagePath/background.svg";
  static const String logo="$_imagePath/logo.svg";
  static const String  newTask="$_imagePath/newtask.png";
  static const String  progress="$_imagePath/progress.png";
  static const String  canceled="$_imagePath/canceled.png";
  static const String  canceled2="$_imagePath/cross.png";
  static const String  completed="$_imagePath/completed.png";
  static const String  completed2="$_imagePath/mark.png";
  static const String  edit="$_imagePath/edit.png";
  static const String delete="$_imagePath/delete.png";
  static const String galleryImage="$_imagePath/gallery.png";
  static const String cameraImage="$_imagePath/add-picture.png";
  static const String userDefaultDp="$_imagePath/user.png";
  static const String  appNameImage="$_imagePath/appName.png";
  static const String  taskLogo="$_imagePath/taskLogo2.png";




}