package com.example.task_manager1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
